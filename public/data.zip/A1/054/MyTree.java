/** Class for a tree node
 */
//sorry I creat city class which is like MyNode class in CitiesDriver.java and also implement with an array in that file
//so I didn't use this file at all
class MyNode {
}

/** Class for a binary tree ADT
 */
public class MyTree {
	// You may want to use an array based implementation for 
	// your tree, or change this to another implementation

	// Note that this code and the driver code do not necessarily
	// match well -- you decide how you want these two parts to work
	// together.

	private final int MAX_NODES = 1000;
	MyNode[] myTree = new MyNode[MAX_NODES];
	int size = 0; // make sure to update this variable as needed

	// fill in your ADT methods here
	// ...
}
