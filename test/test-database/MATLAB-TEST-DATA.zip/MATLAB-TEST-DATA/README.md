# MATLAB Submission Test on SSID

## Specific Non-Programming Files

* **word**: `doc-files-included`
    * **error**: get stuck in processing

* **excel**: `xls-files-included`
    * **error**: cannot visualize submission similarities

* **image**: `jpg-files-included`
    * **error**: cannot visualize submission similarities

* **pdf**: `pdf-files-included`
    * **error**: will compare the `.pdf` file with programming files